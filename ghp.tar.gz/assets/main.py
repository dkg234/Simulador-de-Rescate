import asyncio
import pygame
import random
import heapq
import sys
import math
import itertools
from collections import deque

# =============================================================================
# PROYECTO FINAL: ROBOT DE RESCATE AUTÓNOMO (VERSIÓN MÓVIL CORREGIDA)
# =============================================================================

# --- CONFIGURACIÓN INICIAL ---
ANCHO_TABLERO = 600
ANCHO_PANEL = 250
ANCHO_TOTAL = ANCHO_TABLERO + ANCHO_PANEL
ALTO = 600
FILAS, COLUMNAS = 20, 20
TAMANO_CELDA = ANCHO_TABLERO // COLUMNAS

# Paleta de Colores
FONDO = (30, 30, 40)
TABLERO_FONDO = (50, 50, 60)
GRIS_UI = (80, 80, 90)
BLANCO = (255, 255, 255)
NEGRO = (0, 0, 0)
AZUL = (50, 150, 255)
AZUL_CLARO = (100, 200, 255)
ROJO = (255, 60, 60)
ROSA = (255, 150, 150)
MARRON = (100, 70, 50)
VERDE = (100, 255, 100)
NARANJA = (255, 140, 0)
OSCURO = (20, 20, 25)
OSCURO_CALOR = (30, 30, 50) 
AMARILLO = (255, 215, 0)
VERDE_BASE = (0, 200, 100)
AZUL_PANEL = (0, 150, 255)
GRIS_BOTON = (60, 60, 70)
GRIS_BOTON_HOVER = (100, 100, 110)

# --- VARIABLES GLOBALES ---
estado_app = "MENU" 
config_algoritmo = "A*"
config_dificultad = "Normal" 

entorno = []            
mapa_percibido = []     
mapa_explorado = []     
mapa_probabilidad = []  

robot_pos = (0, 0)
robot_angulo = 1
base_pos = (0, 0)

lista_victimas_reales = []      
lista_victimas_descubiertas = [] 
info_victimas = {} 

objetivo_actual = None
ruta_optima = []
indice_paso = 0
rastro = []

estado_juego = "EXPLORANDO" 
bateria = 100
modo_velocidad = "NORMAL"
estado_conexion = True
algoritmo_actual = "A*"

tiempo_ultimo_derrumbe = 0
tiempo_ultimo_movimiento = 0
tiempo_ultimo_tick_victima = 0
margen_seguridad_bat = 0.10 

tiempo_cargando = 0
carga_interrumpida = False

# --- INICIALIZACIÓN DE PYGAME ---
pygame.init()
pantalla = pygame.display.set_mode((ANCHO_TOTAL, ALTO))
pygame.display.set_caption("Simulador de Rescate - Proyecto Final")
reloj = pygame.time.Clock()
fuente = pygame.font.SysFont("Consolas", 14)
fuente_bold = pygame.font.SysFont("Arial", 14, bold=True)
fuente_grande = pygame.font.SysFont("Arial", 28, bold=True)
fuente_titulo = pygame.font.SysFont("Arial", 40, bold=True)


# =============================================================================
# FUNCIONES DEL ROBOT Y LÓGICA
# =============================================================================

def es_alcanzable(inicio, objetivo, mapa):
    if inicio == objetivo: return True
    cola = deque([inicio])
    visitados = set([inicio])
    
    while cola:
        actual = cola.popleft()
        if actual == objetivo: return True
        
        for df, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nf, nc = actual[0] + df, actual[1] + dc
            if 0 <= nf < FILAS and 0 <= nc < COLUMNAS:
                if mapa[nf][nc] != 1 and (nf, nc) not in visitados:
                    visitados.add((nf, nc))
                    cola.append((nf, nc))
    return False

def zona_segura_para_cargar(pos):
    f, c = pos
    for i in range(max(0, f-1), min(FILAS, f+2)):
        for j in range(max(0, c-1), min(COLUMNAS, c+2)):
            if entorno[i][j] == 1 or entorno[i][j] == 2:
                return False
    return True

def actualizar_sensores():
    global mapa_explorado, mapa_percibido, lista_victimas_descubiertas, estado_conexion
    f, c = robot_pos
    
    if entorno[f][c] == 2:
        estado_conexion = False
    else:
        estado_conexion = True

    for i in range(max(0, f-2), min(FILAS, f+3)):
        for j in range(max(0, c-2), min(COLUMNAS, c+3)):
            mapa_percibido[i][j] = entorno[i][j]
            mapa_explorado[i][j] = 1 

    for i in range(max(0, f-5), min(FILAS, f+6)):
        for j in range(max(0, c-5), min(COLUMNAS, c+6)):
            if (i, j) in lista_victimas_reales and (i, j) not in lista_victimas_descubiertas:
                if math.hypot(i - f, j - c) <= 5.0:
                    lista_victimas_descubiertas.append((i, j))

def obtener_vecinos(pos_actual, mapa):
    f, c = pos_actual
    vecinos = []
    for df, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
        nf, nc = f + df, c + dc
        if 0 <= nf < FILAS and 0 <= nc < COLUMNAS:
            if mapa[nf][nc] != 1: 
                vecinos.append((nf, nc))
    return vecinos

def evasion_local():
    global robot_pos, ruta_optima, indice_paso, bateria
    f, c = robot_pos
    vecinos = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    random.shuffle(vecinos)
    for df, dc in vecinos:
        nf, nc = f + df, c + dc
        if 0 <= nf < FILAS and 0 <= nc < COLUMNAS and entorno[nf][nc] != 1:
            robot_pos = (nf, nc)
            rastro.append(robot_pos)
            ruta_optima = [] 
            indice_paso = 0
            bateria -= 0.5
            return True
    ruta_optima = [] 
    indice_paso = 0
    return False

def gestionar_velocidad():
    global modo_velocidad
    if bateria > 70:
        modo_velocidad = "TURBO"
    elif bateria > 30:
        modo_velocidad = "NORMAL"
    else:
        modo_velocidad = "ECO"

def calcular_costo_real(ruta):
    costo = 0
    if modo_velocidad == "TURBO": multiplicador = 2
    elif modo_velocidad == "ECO": multiplicador = 0.25
    else: multiplicador = 0.5

    for f, c in ruta:
        if entorno[f][c] == 2:
            costo += 3 * multiplicador 
        else:
            costo += 1 * multiplicador
    return costo

def calcular_ruta_TSP(inicio, victimas, mapa):
    if not victimas: return []
    if len(victimas) == 1:
        return calcular_ruta_optima(inicio, victimas[0], mapa, algoritmo_actual)
        
    mejor_costo = float('inf')
    mejor_ruta = []
    permutaciones = list(itertools.permutations(victimas))
    
    for perm in permutaciones:
        ruta_actual = []
        costo_total = 0
        nodo_actual = inicio
        valido = True
        
        for vic in perm:
            tramo = calcular_ruta_optima(nodo_actual, vic, mapa, algoritmo_actual)
            if not tramo:
                valido = False
                break
            costo_total += calcular_costo_real(tramo)
            ruta_actual.extend(tramo[:-1])
            nodo_actual = vic
            
        tramo_final = calcular_ruta_optima(nodo_actual, base_pos, mapa, algoritmo_actual)
        if tramo_final:
            costo_total += calcular_costo_real(tramo_final)
            ruta_actual.extend(tramo_final)
        else:
            valido = False
            
        if valido and costo_total < mejor_costo:
            mejor_costo = costo_total
            mejor_ruta = ruta_actual
            
    return mejor_ruta

def obtener_fronteras():
    fronteras = []
    for f in range(FILAS):
        for c in range(COLUMNAS):
            if mapa_explorado[f][c] == 1 and mapa_percibido[f][c] != 1:
                for df, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                    nf, nc = f + df, c + dc
                    if 0 <= nf < FILAS and 0 <= nc < COLUMNAS:
                        if mapa_explorado[nf][nc] == 0:
                            fronteras.append((f, c))
                            break
    return fronteras

def tomar_decision():
    global objetivo_actual, ruta_optima, indice_paso, estado_juego, bateria, margen_seguridad_bat
    global lista_victimas_descubiertas, lista_victimas_reales, tiempo_cargando, carga_interrumpida
    
    if estado_juego in ["RESCATADO", "SIN_BATERIA", "ATASCADO", "PANICO"]: return

    if estado_juego == "CARGANDO_ESTATICO":
        if not zona_segura_para_cargar(robot_pos):
            estado_juego = "EXPLORANDO"
            tiempo_cargando = 0
            carga_interrumpida = True
        return

    if estado_juego == "RECARGANDO":
        if bateria < 100:
            bateria += 4
            if bateria > 100: bateria = 100
        else:
            estado_juego = "EXPLORANDO"
            margen_seguridad_bat = 0.10 
        return

    if robot_pos != base_pos:
        if bateria < 25:
            ruta_a_base = calcular_ruta_optima(robot_pos, base_pos, mapa_percibido, algoritmo_actual, ignorar_peligro=True)
            if ruta_a_base:
                objetivo_actual = base_pos
                ruta_optima = ruta_a_base
                indice_paso = 0
                return
            else:
                if bateria < 15: estado_juego = "PANICO"
                else: estado_juego = "ATASCADO"
                return
        else:
            ruta_a_base = calcular_ruta_optima(robot_pos, base_pos, mapa_percibido, algoritmo_actual)
            if ruta_a_base:
                costo_regreso = calcular_costo_real(ruta_a_base)
                margen_seguridad_bat = min(margen_seguridad_bat, 0.20)
                
                if bateria - costo_regreso < (bateria * margen_seguridad_bat):
                    if bateria < 40 and zona_segura_para_cargar(robot_pos):
                        estado_juego = "CARGANDO_ESTATICO"
                        tiempo_cargando = 0
                        ruta_optima = []
                        return
                    else:
                        objetivo_actual = base_pos
                        ruta_optima = ruta_a_base
                        indice_paso = 0
                        return

    if robot_pos == base_pos and bateria < 100:
        estado_juego = "RECARGANDO"
        ruta_optima = []
        objetivo_actual = None
        return

    if not ruta_optima or robot_pos == objetivo_actual or indice_paso >= len(ruta_optima) - 1:
        
        if robot_pos in lista_victimas_descubiertas:
            lista_victimas_descubiertas.remove(robot_pos)
            if robot_pos in lista_victimas_reales:
                lista_victimas_reales.remove(robot_pos)
            if not lista_victimas_descubiertas:
                objetivo_actual = None
                
        if not lista_victimas_reales:
            estado_juego = "RESCATADO"
            return

        ruta_encontrada = False

        victima_critica = None
        for vic in lista_victimas_descubiertas:
            if info_victimas.get(vic, {}).get("critico", False):
                victima_critica = vic
                break 

        if victima_critica:
            ruta_temp = calcular_ruta_optima(robot_pos, victima_critica, mapa_percibido, algoritmo_actual)
            if ruta_temp:
                objetivo_actual = victima_critica
                ruta_optima = ruta_temp
                indice_paso = 0
                ruta_encontrada = True

        if not ruta_encontrada and lista_victimas_descubiertas:
            ruta_temp = calcular_ruta_TSP(robot_pos, lista_victimas_descubiertas, mapa_percibido)
            if ruta_temp:
                ruta_optima = ruta_temp
                for paso in ruta_optima:
                    if paso in lista_victimas_descubiertas:
                        objetivo_actual = paso
                        break
                indice_paso = 0
                ruta_encontrada = True

        if not ruta_encontrada:
            fronteras = obtener_fronteras()
            if fronteras:
                celdas_ordenadas = sorted(fronteras, key=lambda v: abs(v[0]-robot_pos[0]) + abs(v[1]-robot_pos[1]))
                for celda in celdas_ordenadas:
                    ruta_temp = calcular_ruta_optima(robot_pos, celda, mapa_percibido, algoritmo_actual)
                    if ruta_temp:
                        objetivo_actual = celda
                        ruta_optima = ruta_temp
                        indice_paso = 0
                        ruta_encontrada = True
                        break
            
            if not ruta_encontrada:
                celdas_no_exploradas = [(f, c) for f in range(FILAS) for c in range(COLUMNAS) if mapa_explorado[f][c] == 0]
                if celdas_no_exploradas:
                    objetivo_actual = min(celdas_no_exploradas, key=lambda v: abs(v[0]-robot_pos[0]) + abs(v[1]-robot_pos[1]))
                    ruta_optima = calcular_ruta_optima(robot_pos, objetivo_actual, mapa_percibido, algoritmo_actual)
                    indice_paso = 0
                else:
                    if bateria < 15: estado_juego = "PANICO"
                    else: estado_juego = "ATASCADO"

def mover_robot():
    global robot_pos, indice_paso, bateria, robot_angulo, rastro, estado_juego, margen_seguridad_bat
    global tiempo_cargando, carga_interrumpida
    
    if estado_juego in ["RESCATADO", "SIN_BATERIA", "ATASCADO", "PANICO", "RECARGANDO", "CARGANDO_ESTATICO"]: 
        return

    gestionar_velocidad()

    if ruta_optima and indice_paso < len(ruta_optima) - 1:
        siguiente = ruta_optima[indice_paso + 1]
        
        if entorno[siguiente[0]][siguiente[1]] == 1:
            margen_seguridad_bat += 0.05 
            evasion_local()
            return
            
        df = siguiente[0] - robot_pos[0]
        dc = siguiente[1] - robot_pos[1]
        ang_req = 0 if df == -1 else (1 if dc == 1 else (2 if df == 1 else 3))

        if robot_angulo != ang_req:
            robot_angulo = ang_req
            bateria -= 0.1 
        else:
            indice_paso += 1
            robot_pos = siguiente
            rastro.append(robot_pos)
            
            costo_base = 0.5
            if modo_velocidad == "TURBO": costo_base = 2
            elif modo_velocidad == "ECO": costo_base = 0.25

            if entorno[robot_pos[0]][robot_pos[1]] == 2:
                bateria -= costo_base * 3 
            else:
                bateria -= costo_base
                
            if bateria <= 0:
                bateria = 0
                dist_manhattan = abs(robot_pos[0]-base_pos[0]) + abs(robot_pos[1]-base_pos[1])
                if dist_manhattan <= 1:
                    estado_juego = "RECARGANDO"
                else:
                    if robot_pos != base_pos:
                        estado_juego = "PANICO"
                    else:
                        estado_juego = "SIN_BATERIA"

def calcular_ruta_optima(inicio, objetivo, mapa, algoritmo, ignorar_peligro=False):
    if not objetivo: return []
    cola = [(0, inicio, 0)]
    visitados = set()
    padres = {}
    costo_g = {inicio: 0}

    while cola:
        _, (f, c), g_actual = heapq.heappop(cola)
        if (f, c) == objetivo:
            camino = []
            actual = objetivo
            while actual in padres:
                camino.append(actual)
                actual = padres[actual]
            camino.append(inicio)
            return camino[::-1]

        if (f, c) in visitados: continue
        visitados.add((f, c))

        for nf, nc in obtener_vecinos((f, c), mapa):
            if ignorar_peligro:
                costo_mov = 1
            else:
                costo_mov = 10 if mapa[nf][nc] == 2 else 1
                
            nuevo_g = g_actual + costo_mov
            if (nf, nc) not in costo_g or nuevo_g < costo_g[(nf, nc)]:
                costo_g[(nf, nc)] = nuevo_g
                h = abs(nf - objetivo[0]) + abs(nc - objetivo[1]) if algoritmo == "A*" else 0
                heapq.heappush(cola, (nuevo_g + h, (nf, nc), nuevo_g))
                padres[(nf, nc)] = (f, c)
    return []

def generar_entorno():
    global entorno, mapa_percibido, mapa_explorado, mapa_probabilidad
    global robot_pos, lista_victimas_reales, lista_victimas_descubiertas, info_victimas, estado_juego, bateria, robot_angulo, ruta_optima, indice_paso, objetivo_actual, rastro, algoritmo_actual, margen_seguridad_bat, tiempo_cargando, carga_interrumpida
    
    algoritmo_actual = config_algoritmo
    entorno = [[0 for _ in range(COLUMNAS)] for _ in range(FILAS)]
    mapa_percibido = [[0 for _ in range(COLUMNAS)] for _ in range(FILAS)]
    mapa_explorado = [[0 for _ in range(COLUMNAS)] for _ in range(FILAS)]
    mapa_probabilidad = [[0 for _ in range(COLUMNAS)] for _ in range(FILAS)]
    rastro = []
    info_victimas = {}
    tiempo_cargando = 0
    carga_interrumpida = False
    
    prob_escombro, prob_peligro, num_victimas = 0.20, 0.35, 3
    if config_dificultad == "Facil":
        prob_escombro, prob_peligro, num_victimas = 0.10, 0.20, 2
    elif config_dificultad == "Dificil":
        prob_escombro, prob_peligro, num_victimas = 0.30, 0.45, 4

    for f in range(FILAS):
        for c in range(COLUMNAS):
            prob = random.random()
            if prob < prob_escombro: entorno[f][c] = 1
            elif prob < prob_peligro: entorno[f][c] = 2
                
    robot_pos = base_pos
    entorno[robot_pos[0]][robot_pos[1]] = 0
    entorno[base_pos[0]][base_pos[1]] = 0
    
    for _ in range(3):
        centro_f = random.randint(5, FILAS-1)
        centro_c = random.randint(5, COLUMNAS-1)
        for f in range(FILAS):
            for c in range(COLUMNAS):
                dist = math.hypot(f - centro_f, c - centro_c)
                if dist < 6:
                    mapa_probabilidad[f][c] += 1

    alcanzables = set()
    cola_bfs = deque([base_pos])
    while cola_bfs:
        cf, cc = cola_bfs.popleft()
        if (cf, cc) in alcanzables: continue
        if entorno[cf][cc] == 1: continue
        
        alcanzables.add((cf, cc))
        for df, dc in [(-1,0),(1,0),(0,-1),(0,1)]:
            nf, nc = cf+df, cc+dc
            if 0 <= nf < FILAS and 0 <= nc < COLUMNAS and (nf,nc) not in alcanzables:
                cola_bfs.append((nf,nc))

    lista_alcanzables = list(alcanzables)
    if base_pos in lista_alcanzables: lista_alcanzables.remove(base_pos)

    lista_victimas_reales = []
    intentos = 0
    while len(lista_victimas_reales) < num_victimas and intentos < 1000:
        intentos += 1
        if random.random() < 0.7: 
            f, c = random.randint(5, 19), random.randint(5, 19)
            if mapa_probabilidad[f][c] == 0 or (f,c) not in alcanzables: continue
        else:
            if not lista_alcanzables: break
            f, c = random.choice(lista_alcanzables)

        if (f, c) not in lista_victimas_reales and (f,c) in alcanzables and entorno[f][c] == 0:
            lista_victimas_reales.append((f, c))
            es_critico = random.random() < 0.3
            info_victimas[(f, c)] = {"critico": es_critico, "tiempo": 120 if es_critico else 9999}
            
    lista_victimas_descubiertas = []
    estado_juego = "EXPLORANDO"
    indice_paso = 0
    bateria = 100
    robot_angulo = 1
    objetivo_actual = None
    margen_seguridad_bat = 0.10
    actualizar_sensores()
    tomar_decision()

def generar_derrumbe():
    global entorno, estado_juego, carga_interrumpida
    if estado_juego not in ["EXPLORANDO", "RESCATE", "RECARGANDO", "CARGANDO_ESTATICO"]: return
    
    intentos = 0
    while intentos < 50:
        intentos += 1
        f, c = random.randint(0, FILAS-1), random.randint(0, COLUMNAS-1)
        
        if (f, c) != robot_pos and (f, c) != base_pos and (f, c) not in lista_victimas_reales and entorno[f][c] == 0:
            entorno[f][c] = 1
            
            base_ok = es_alcanzable(robot_pos, base_pos, entorno)
            objetivo_ok = True
            if objetivo_actual and objetivo_actual != base_pos:
                 if not es_alcanzable(robot_pos, objetivo_actual, entorno):
                     objetivo_ok = False
            
            if base_ok and objetivo_ok:
                break
            else:
                entorno[f][c] = 0
            
    if estado_juego == "CARGANDO_ESTATICO":
        if not zona_segura_para_cargar(robot_pos):
            estado_juego = "EXPLORANDO"
            carga_interrumpida = True

# =============================================================================
# INTERFAZ GRÁFICA
# =============================================================================
def dibujar_menu():
    pantalla.fill(FONDO)
    titulo = fuente_titulo.render("SIMULADOR DE RESCATE", True, BLANCO)
    pantalla.blit(titulo, (ANCHO_TOTAL//2 - titulo.get_width()//2, 80))
    
    txt_alg = fuente_bold.render("Algoritmo de Búsqueda:", True, BLANCO)
    pantalla.blit(txt_alg, (150, 200))
    
    color_a = AZUL if config_algoritmo == "A*" else GRIS_UI
    pygame.draw.rect(pantalla, color_a, (150, 230, 200, 40), border_radius=5)
    pantalla.blit(fuente_bold.render("A* (Heurístico)", True, BLANCO), (170, 240))
    
    color_d = AZUL if config_algoritmo == "DIJKSTRA" else GRIS_UI
    pygame.draw.rect(pantalla, color_d, (400, 230, 200, 40), border_radius=5)
    pantalla.blit(fuente_bold.render("Dijkstra (Exhaustivo)", True, BLANCO), (420, 240))

    txt_dif = fuente_bold.render("Nivel de Dificultad:", True, BLANCO)
    pantalla.blit(txt_dif, (150, 320))
    
    color_f = VERDE if config_dificultad == "Facil" else GRIS_UI
    pygame.draw.rect(pantalla, color_f, (150, 350, 130, 40), border_radius=5)
    pantalla.blit(fuente_bold.render("Fácil", True, BLANCO), (185, 360))
    
    color_n = AMARILLO if config_dificultad == "Normal" else GRIS_UI
    pygame.draw.rect(pantalla, color_n, (310, 350, 130, 40), border_radius=5)
    pantalla.blit(fuente_bold.render("Normal", True, NEGRO if config_dificultad == "Normal" else BLANCO), (335, 360))
    
    color_dif = ROJO if config_dificultad == "Dificil" else GRIS_UI
    pygame.draw.rect(pantalla, color_dif, (470, 350, 130, 40), border_radius=5)
    pantalla.blit(fuente_bold.render("Difícil", True, BLANCO), (500, 360))

    pygame.draw.rect(pantalla, VERDE_BASE, (ANCHO_TOTAL//2 - 150, 480, 300, 60), border_radius=8)
    txt_iniciar = fuente_grande.render("INICIAR MISIÓN", True, NEGRO)
    pantalla.blit(txt_iniciar, (ANCHO_TOTAL//2 - txt_iniciar.get_width()//2, 495))

def dibujar_tablero():
    pygame.draw.rect(pantalla, TABLERO_FONDO, (0, 0, ANCHO_TABLERO, ALTO))
    
    for f in range(FILAS):
        for c in range(COLUMNAS):
            rect = pygame.Rect(c * TAMANO_CELDA, f * TAMANO_CELDA, TAMANO_CELDA, TAMANO_CELDA)
            if mapa_explorado[f][c] == 1:
                if mapa_percibido[f][c] == 1: 
                    pygame.draw.rect(pantalla, MARRON, rect)
                    pygame.draw.rect(pantalla, (60, 40, 30), rect, 2)
                elif mapa_percibido[f][c] == 2: 
                    pygame.draw.rect(pantalla, NARANJA, rect)
                    pygame.draw.line(pantalla, (200, 100, 0), (rect.x, rect.y), (rect.x+TAMANO_CELDA, rect.y+TAMANO_CELDA), 2)
                    pygame.draw.line(pantalla, (200, 100, 0), (rect.x+TAMANO_CELDA, rect.y), (rect.x, rect.y+TAMANO_CELDA), 2)
                else: 
                    pygame.draw.rect(pantalla, (60, 60, 70), rect)
                    pygame.draw.rect(pantalla, (40, 40, 50), rect, 1)
            else:
                if mapa_probabilidad[f][c] > 0:
                    pygame.draw.rect(pantalla, OSCURO_CALOR, rect)
                else:
                    pygame.draw.rect(pantalla, OSCURO, rect)

    for paso in rastro:
        if mapa_explorado[paso[0]][paso[1]] == 1:
            rect = pygame.Rect(paso[1] * TAMANO_CELDA + 8, paso[0] * TAMANO_CELDA + 8, TAMANO_CELDA-16, TAMANO_CELDA-16)
            pygame.draw.rect(pantalla, AZUL_CLARO, rect)

    for i, paso in enumerate(ruta_optima):
        if mapa_explorado[paso[0]][paso[1]] == 1 and i % 2 == 0:
            rect = pygame.Rect(paso[1] * TAMANO_CELDA + 12, paso[0] * TAMANO_CELDA + 12, 6, 6)
            pygame.draw.ellipse(pantalla, VERDE, rect)

    rect_b = pygame.Rect(base_pos[1] * TAMANO_CELDA, base_pos[0] * TAMANO_CELDA, TAMANO_CELDA, TAMANO_CELDA)
    pygame.draw.rect(pantalla, VERDE_BASE, rect_b)
    pygame.draw.rect(pantalla, BLANCO, rect_b, 2)

    tiempo_actual = pygame.time.get_ticks()
    for vic in lista_victimas_descubiertas:
        es_critico = info_victimas.get(vic, {}).get("critico", False)
        
        if es_critico:
            pulso = (math.sin(tiempo_actual * 0.02) + 1) / 2 
            tam_vic = int(TAMANO_CELDA * (0.6 + 0.3 * pulso))
            color_vic = ROJO
        else:
            pulso = (math.sin(tiempo_actual * 0.005) + 1) / 2
            tam_vic = int(TAMANO_CELDA * (0.6 + 0.1 * pulso))
            color_vic = ROSA

        offset = (TAMANO_CELDA - tam_vic) // 2
        rect_v = pygame.Rect(vic[1] * TAMANO_CELDA + offset, vic[0] * TAMANO_CELDA + offset, tam_vic, tam_vic)
        pygame.draw.rect(pantalla, color_vic, rect_v, border_radius=4)
        pygame.draw.rect(pantalla, BLANCO, rect_v, 1, border_radius=4)

    cx = robot_pos[1] * TAMANO_CELDA + TAMANO_CELDA // 2
    cy = robot_pos[0] * TAMANO_CELDA + TAMANO_CELDA // 2
    
    if estado_juego == "PANICO":
        if (tiempo_actual // 200) % 2 == 0:
            pygame.draw.circle(pantalla, ROJO, (cx, cy), 12)
    elif estado_juego == "CARGANDO_ESTATICO":
        pygame.draw.rect(pantalla, AZUL_PANEL, (cx-18, cy-2, 36, 4))
        pygame.draw.rect(pantalla, GRIS_UI, (cx-2, cy-18, 4, 36))
        pygame.draw.circle(pantalla, AZUL, (cx, cy), 9)
    else:
        if robot_angulo == 0 or robot_angulo == 2: 
            pygame.draw.rect(pantalla, GRIS_UI, (cx-10, cy-12, 6, 24), border_radius=2)
            pygame.draw.rect(pantalla, GRIS_UI, (cx+4, cy-12, 6, 24), border_radius=2)
        else: 
            pygame.draw.rect(pantalla, GRIS_UI, (cx-12, cy-10, 24, 6), border_radius=2)
            pygame.draw.rect(pantalla, GRIS_UI, (cx-12, cy+4, 24, 6), border_radius=2)
            
        pygame.draw.circle(pantalla, AZUL, (cx, cy), 9)
        
        if robot_angulo == 0: luz = (cx, cy-12)
        elif robot_angulo == 1: luz = (cx+12, cy)
        elif robot_angulo == 2: luz = (cx, cy+12)
        else: luz = (cx-12, cy)
        pygame.draw.circle(pantalla, AMARILLO, luz, 4)

def dibujar_panel():
    pygame.draw.rect(pantalla, FONDO, (ANCHO_TABLERO, 0, ANCHO_PANEL, ALTO))
    pygame.draw.line(pantalla, GRIS_UI, (ANCHO_TABLERO, 0), (ANCHO_TABLERO, ALTO), 3)
    
    x_texto, y_texto = ANCHO_TABLERO + 20, 20
    
    pantalla.blit(fuente_bold.render("TELEMETRÍA", True, BLANCO), (x_texto, y_texto))
    y_texto += 30
    
    pantalla.blit(fuente.render(f"BATERÍA: {int(bateria)}%", True, BLANCO), (x_texto, y_texto))
    y_texto += 20
    pygame.draw.rect(pantalla, GRIS_UI, (x_texto, y_texto, 200, 15), border_radius=5)
    ancho_bateria = int((bateria / 100) * 200)
    if bateria > 60: color_bat = (0, 255, 0)
    elif bateria > 30: color_bat = (255, 255, 0)
    else: color_bat = (255, 0, 0)
    if ancho_bateria > 0:
        pygame.draw.rect(pantalla, color_bat, (x_texto, y_texto, ancho_bateria, 15), border_radius=5)
    y_texto += 30

    color_modo = VERDE if modo_velocidad == "ECO" else (ROJO if modo_velocidad == "TURBO" else BLANCO)
    pantalla.blit(fuente.render(f"MODO: {modo_velocidad}", True, color_modo), (x_texto, y_texto))
    y_texto += 20

    color_com = VERDE if estado_conexion else ROJO
    texto_com = "SEÑAL: OK" if estado_conexion else "SEÑAL: PERDIDA"
    pantalla.blit(fuente.render(texto_com, True, color_com), (x_texto, y_texto))
    y_texto += 20

    pantalla.blit(fuente.render(f"Víctimas Detectadas: {len(lista_victimas_descubiertas)}", True, BLANCO), (x_texto, y_texto))
    y_texto += 20
    
    v_criticas = sum(1 for v in lista_victimas_descubiertas if info_victimas.get(v, {}).get("critico", False))
    v_estables = len(lista_victimas_descubiertas) - v_criticas
    
    pantalla.blit(fuente.render(f"  - Críticas: {v_criticas}", True, ROJO), (x_texto, y_texto))
    y_texto += 20
    pantalla.blit(fuente.render(f"  - Estables: {v_estables}", True, ROSA), (x_texto, y_texto))
    y_texto += 20

    tiempo_critico = 9999
    for v in lista_victimas_descubiertas:
        if info_victimas.get(v, {}).get("critico", False):
            tiempo_critico = min(tiempo_critico, info_victimas[v]["tiempo"])
            
    if tiempo_critico < 9999:
        if tiempo_critico < 30 and (pygame.time.get_ticks() // 500) % 2 == 0:
            color_timer = BLANCO
        else:
            color_timer = ROJO
        pantalla.blit(fuente.render(f"  [!] Alerta: {tiempo_critico}s", True, color_timer), (x_texto, y_texto))
    y_texto += 20

    pantalla.blit(fuente.render(f"Víctimas Restantes: {len(lista_victimas_reales)}", True, AMARILLO), (x_texto, y_texto))
    y_texto += 20
    
    pantalla.blit(fuente.render(f"Margen Precaución: {int(margen_seguridad_bat*100)}%", True, GRIS_UI), (x_texto, y_texto))
    y_texto += 30

    color_alg = (0, 255, 255) if algoritmo_actual == "A*" else (255, 100, 255)
    pantalla.blit(fuente.render(f"Algoritmo: {algoritmo_actual}", True, color_alg), (x_texto, y_texto))
    y_texto += 30

    pantalla.blit(fuente_bold.render("ESTADO ACTUAL:", True, GRIS_UI), (x_texto, y_texto))
    y_texto += 20
    
    if estado_juego == "RECARGANDO":
        pygame.draw.circle(pantalla, VERDE_BASE, (x_texto+5, y_texto+7), 5)
        pantalla.blit(fuente.render("Recargando en Base...", True, VERDE_BASE), (x_texto+15, y_texto))
    elif estado_juego == "CARGANDO_ESTATICO":
        pygame.draw.circle(pantalla, AZUL_PANEL, (x_texto+5, y_texto+7), 5)
        pantalla.blit(fuente.render("Panel Solar Activo", True, AZUL_PANEL), (x_texto+15, y_texto))
        y_texto += 20
        pantalla.blit(fuente.render(f"Tiempo de carga: {tiempo_cargando}s", True, BLANCO), (x_texto, y_texto))
        if carga_interrumpida:
            y_texto += 20
            pantalla.blit(fuente.render("¡Carga interrumpida!", True, ROJO), (x_texto, y_texto))
    elif estado_juego == "SIN_BATERIA":
        pygame.draw.circle(pantalla, ROJO, (x_texto+5, y_texto+7), 5)
        pantalla.blit(fuente.render("Batería Agotada", True, ROJO), (x_texto+15, y_texto))
    elif estado_juego == "ATASCADO":
        pygame.draw.circle(pantalla, ROJO, (x_texto+5, y_texto+7), 5)
        pantalla.blit(fuente.render("Zona Explorada", True, ROJO), (x_texto+15, y_texto))
    elif estado_juego == "RESCATADO":
        pygame.draw.circle(pantalla, VERDE, (x_texto+5, y_texto+7), 5)
        pantalla.blit(fuente.render("¡Misión Cumplida!", True, VERDE), (x_texto+15, y_texto))
    elif estado_juego == "PANICO":
        pygame.draw.circle(pantalla, ROJO, (x_texto+5, y_texto+7), 5)
        pantalla.blit(fuente.render("¡PÁNICO! Auxilio", True, ROJO), (x_texto+15, y_texto))
    else:
        pygame.draw.circle(pantalla, AZUL, (x_texto+5, y_texto+7), 5)
        pantalla.blit(fuente.render("Buscando...", True, AZUL), (x_texto+15, y_texto))

    # --- BOTONES TÁCTILES (Con Hitboxes Ampliadas) ---
    y_controles = ALTO - 100
    pygame.draw.line(pantalla, GRIS_UI, (ANCHO_TABLERO + 10, y_controles - 10), (ANCHO_TOTAL - 10, y_controles - 10), 1)
    
    # Rectángulos visuales
    btn_m = pygame.Rect(x_texto, y_controles + 10, 100, 25)
    btn_r = pygame.Rect(x_texto + 110, y_controles + 10, 100, 25)
    btn_1 = pygame.Rect(x_texto, y_controles + 40, 100, 25)
    btn_2 = pygame.Rect(x_texto + 110, y_controles + 40, 100, 25)
    
    mouse_pos = pygame.mouse.get_pos()
    
    color_m = GRIS_BOTON_HOVER if btn_m.collidepoint(mouse_pos) else GRIS_BOTON
    pygame.draw.rect(pantalla, color_m, btn_m, border_radius=4)
    pantalla.blit(fuente.render("[M] Menú", True, BLANCO), (btn_m.x + 10, btn_m.y + 5))
    
    color_r = GRIS_BOTON_HOVER if btn_r.collidepoint(mouse_pos) else GRIS_BOTON
    pygame.draw.rect(pantalla, color_r, btn_r, border_radius=4)
    pantalla.blit(fuente.render("[R] Reiniciar", True, BLANCO), (btn_r.x + 5, btn_r.y + 5))

    color_1 = GRIS_BOTON_HOVER if btn_1.collidepoint(mouse_pos) else GRIS_BOTON
    pygame.draw.rect(pantalla, color_1, btn_1, border_radius=4)
    pantalla.blit(fuente.render("[1] Algo A*", True, BLANCO), (btn_1.x + 5, btn_1.y + 5))

    color_2 = GRIS_BOTON_HOVER if btn_2.collidepoint(mouse_pos) else GRIS_BOTON
    pygame.draw.rect(pantalla, color_2, btn_2, border_radius=4)
    pantalla.blit(fuente.render("[2] Dijkstra", True, BLANCO), (btn_2.x + 5, btn_2.y + 5))

    if estado_juego in ["RESCATADO", "SIN_BATERIA", "ATASCADO", "PANICO"]:
        if estado_juego == "PANICO":
            texto_fin = fuente_grande.render("SEÑAL DE AUXILIO ENVIADA", True, ROJO)
        else:
            texto_fin = fuente_grande.render("FIN DE LA MISIÓN", True, ROJO if estado_juego != "RESCATADO" else VERDE)
            
        rect_fin = texto_fin.get_rect(center=(ANCHO_TABLERO//2, ALTO//2 - 20))
        pygame.draw.rect(pantalla, NEGRO, rect_fin.inflate(20, 20))
        pantalla.blit(texto_fin, rect_fin)
        txt_menu = fuente.render("Toca la pantalla o presiona 'M'", True, BLANCO)
        rect_menu = txt_menu.get_rect(center=(ANCHO_TABLERO//2, ALTO//2 + 20))
        pantalla.blit(txt_menu, rect_menu)

# =============================================================================
# BUCLE PRINCIPAL ASÍNCRONO
# =============================================================================
async def main():
    global estado_app, config_algoritmo, config_dificultad
    global entorno, mapa_percibido, mapa_explorado, mapa_probabilidad
    global robot_pos, robot_angulo, base_pos
    global lista_victimas_reales, lista_victimas_descubiertas, info_victimas
    global objetivo_actual, ruta_optima, indice_paso, rastro, estado_juego
    global bateria, modo_velocidad, estado_conexion, algoritmo_actual
    global tiempo_ultimo_derrumbe, tiempo_ultimo_movimiento, tiempo_ultimo_tick_victima
    global margen_seguridad_bat, tiempo_cargando, carga_interrumpida

    generar_entorno()
    
    ejecutando = True
    while ejecutando:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                ejecutando = False
                
            if evento.type == pygame.KEYDOWN:
                if estado_app == "JUGANDO":
                    if evento.key == pygame.K_m: estado_app = "MENU"
                    if evento.key == pygame.K_r: generar_entorno()
                    if evento.key == pygame.K_1 and estado_juego == "BUSCANDO": 
                        algoritmo_actual = "A*"
                        config_algoritmo = "A*"
                        tomar_decision()
                    if evento.key == pygame.K_2 and estado_juego == "BUSCANDO":
                        algoritmo_actual = "DIJKSTRA"
                        config_algoritmo = "DIJKSTRA"
                        tomar_decision()

            if evento.type == pygame.MOUSEBUTTONDOWN:
                # Usamos evento.pos para mayor precisión en pantallas táctiles
                mouse_x, mouse_y = evento.pos
                
                if estado_app == "MENU":
                    if 150 <= mouse_x <= 350 and 230 <= mouse_y <= 270: config_algoritmo = "A*"
                    elif 400 <= mouse_x <= 600 and 230 <= mouse_y <= 270: config_algoritmo = "DIJKSTRA"
                    elif 150 <= mouse_x <= 280 and 350 <= mouse_y <= 390: config_dificultad = "Facil"
                    elif 310 <= mouse_x <= 440 and 350 <= mouse_y <= 390: config_dificultad = "Normal"
                    elif 470 <= mouse_x <= 600 and 350 <= mouse_y <= 390: config_dificultad = "Dificil"
                    elif ANCHO_TOTAL//2 - 150 <= mouse_x <= ANCHO_TOTAL//2 + 150 and 480 <= mouse_y <= 540:
                        estado_app = "JUGANDO"
                        generar_entorno() 
                        
                elif estado_app == "JUGANDO":
                    # --- ZONAS DE TOQUE AMPLIADAS (+-10 px) ---
                    
                    # Botón M (Menú)
                    if ANCHO_TABLERO + 10 <= mouse_x <= ANCHO_TABLERO + 130 and ALTO - 95 <= mouse_y <= ALTO - 55:
                        estado_app = "MENU"
                        
                    # Botón R (Reiniciar)
                    elif ANCHO_TABLERO + 120 <= mouse_x <= ANCHO_TABLERO + 240 and ALTO - 95 <= mouse_y <= ALTO - 55:
                        generar_entorno()
                        
                    # Botón 1 (A*)
                    elif ANCHO_TABLERO + 10 <= mouse_x <= ANCHO_TABLERO + 130 and ALTO - 65 <= mouse_y <= ALTO - 25:
                        algoritmo_actual = "A*"
                        config_algoritmo = "A*"
                        tomar_decision()
                        
                    # Botón 2 (Dijkstra)
                    elif ANCHO_TABLERO + 120 <= mouse_x <= ANCHO_TABLERO + 240 and ALTO - 65 <= mouse_y <= ALTO - 25:
                        algoritmo_actual = "DIJKSTRA"
                        config_algoritmo = "DIJKSTRA"
                        tomar_decision()
                    
                    # Tocar la pantalla si el juego terminó para volver al menú
                    if estado_juego in ["RESCATADO", "SIN_BATERIA", "ATASCADO", "PANICO"]:
                        estado_app = "MENU"

        if estado_app == "JUGANDO":
            tiempo_actual = pygame.time.get_ticks()

            delay_movimiento = 150 
            if modo_velocidad == "TURBO": delay_movimiento = 70
            elif modo_velocidad == "ECO": delay_movimiento = 250

            if tiempo_actual - tiempo_ultimo_tick_victima > 1000:
                for vic, info in list(info_victimas.items()):
                    if info["critico"] and info["tiempo"] > 0:
                        info["tiempo"] -= 1
                        if info["tiempo"] == 0:
                            if vic in lista_victimas_reales: lista_victimas_reales.remove(vic)
                            if vic in lista_victimas_descubiertas: lista_victimas_descubiertas.remove(vic)
                tiempo_ultimo_tick_victima = tiempo_actual

            if estado_juego == "CARGANDO_ESTATICO":
                if not zona_segura_para_cargar(robot_pos):
                    estado_juego = "EXPLORANDO"
                    carga_interrumpida = True
                else:
                    bateria += 0.5
                    if bateria > 100: bateria = 100
                    tiempo_cargando += 1
                    
                    if bateria >= 100 or tiempo_cargando >= 15:
                        estado_juego = "EXPLORANDO"

            if estado_juego not in ["PANICO", "SIN_BATERIA", "RESCATADO", "ATASCADO", "CARGANDO_ESTATICO"]:
                if tiempo_actual - tiempo_ultimo_movimiento > delay_movimiento:
                    mover_robot()
                    actualizar_sensores()
                    tomar_decision()
                    tiempo_ultimo_movimiento = tiempo_actual

                if tiempo_actual - tiempo_ultimo_derrumbe > 4000:
                    generar_derrumbe()
                    tiempo_ultimo_derrumbe = tiempo_actual
            else:
                if tiempo_actual - tiempo_ultimo_derrumbe > 4000:
                    generar_derrumbe()
                    tiempo_ultimo_derrumbe = tiempo_actual

            dibujar_tablero()
            dibujar_panel()
            
        elif estado_app == "MENU":
            dibujar_menu()

        pygame.display.flip()
        reloj.tick(60)
        
        # Línea vital para que el navegador no se congele
        await asyncio.sleep(0)

    pygame.quit()

if __name__ == '__main__':
    asyncio.run(main())